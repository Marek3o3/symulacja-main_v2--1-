A więc, instrukcja:
Ustawione jest 20 satelit, pomniejszona ilość klatek oraz klatek akwizycji.
Wszystko zmieniajcie w config.py
aby to działało musimy ustawić przepływność bitową na 428 Mbps.
A, wszystko tyczy się GeoEye1, gdzie łącznie 45 TB policzyłem - 303 MB/zdjęcie - 151 815 zdjęć - 759 zdjęć/satelita (przy założeniu 200 satelit).
35 satelit odbiorczych (w sumie tego nie sprawdzalem przekleilem z kodu Patryka)
Średnica odbioru każdej satelity to 2400 km. 
Sumaryczny czas transmisji (przez 2h i 20 satelit) to 7 020s czyli essa jakoś to idzie,
uprzedzajac pytania - tak uwzglednilem ze tylko jeden na raz moze sie polaczyc ze stacja naziemna takze luz, choc inaczej to wyglada na filmie
a ogolnie jak chcecie zeby to wygladalo jak najbardziej wyraznie to pozmieniajcie te wszystkie wodowtryski, ale przy 200 satelitach robiło mi się to jakieś 2h na moim laptopie,
na waszych maszynach może do godziny.
